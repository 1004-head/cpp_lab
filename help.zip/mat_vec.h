#ifndef HEADER_H
# define HEADER_H

#include <stdio.h>

int add(int x, int y);
int sub(int x, int y);
int mul(int x, int y);
int div(int x, int y);

#endif