#include "mat_vec.h"

int main(){

    int x = 10, y = 5;

    printf("add : %d\n", add(x, y));
    printf("sub : %d\n", sub(x, y));
    printf("mul : %d\n", mul(x, y));
    printf("div : %d\n", div(x, y));

    return 0;
}